# Dead Money (Art Slice)

Objetivo: un vertical slice **visual** para Victoria 3 1.9.x: mapa de Norteamérica (placeholder), 
iconos de bienes/edificios, y tuberías para modelos 3D. El gameplay vendrá después.

## Estructura
- `gfx/interface/icons/...` iconos en **PNG** (luego convertir a **DDS**).
- `gfx/models/buildings` y `gfx/models/units`: espacio para `.mesh`/`.asset`/texturas.
- `map_data/`: `heightmap.png`, `provinces.png` y `rivers.png` de ejemplo (placeholders).
- `localization/english/deadmoney_l_english.yml`: llaves mínimas para evitar errores.

## Notas rápidas
- **DDS** es el formato recomendado para texturas en el motor Clausewitz. Convierte los PNG con herramientas como texconv o GIMP.
- `supported_version` está en `1.9.*` para que funcione con 1.9.3.
- Este paquete no incluye modelos `.mesh` reales; es una plantilla para empezar sin errores fatales.
