name="Dead Money"
version="0.0.1"
supported_version="1.9.*"
path="mod/DeadMoney"
tags={ "Total Conversion" "Graphics" }
remote_file_id=""
