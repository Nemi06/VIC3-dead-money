# Pipeline visual rápido

## Texturas
- Trabaja en **PNG** a 512–1024 px para iconos, 2K–4K para edificios/unidades.
- Convierte a **DDS** (BC1/BC3, mipmaps on). Nombres en minúsculas, sin espacios.

## Modelos 3D
- Exporta a `.mesh` con los plugins de Paradox (Blender/Maya) y genera `.asset` que apunte a materiales/texturas.
- Coloca en `gfx/models/buildings` o `gfx/models/units` y referencia desde un `.asset` (ver ejemplos cuando añadamos modelos reales).

## Mapa (placeholder)
- `map_data/heightmap.png`: 2048×1024 (por ahora llano). 
- `map_data/provinces.png`: 2048×1024 con bloques de color únicos de muestra.
- Más adelante generaremos provincias reales y `state_regions`.

## Convenciones
- Prefijo `dm_` para todos los nombres de archivos/llaves: `dm_clean_water.dds`, `dm_building_water_purifier.asset`.
